@extends('adminlte::page')

@section('title', 'Suino App')

@section('content_header')
   <h1>Atualizações</h1>
@stop

@section('content')

    <h1>Em Breve...</h1>
    <h1></h1>

@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
@stop
